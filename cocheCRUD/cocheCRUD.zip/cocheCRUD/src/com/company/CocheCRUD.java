package com.company;

public interface CocheCRUD {
    void save();
    void findall();
    void delete();
}
