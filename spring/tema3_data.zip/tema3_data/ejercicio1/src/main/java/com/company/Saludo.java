package com.company;

public class Saludo {
    public void  imprimirSaludo(){
        System.out.println("Hola mundo");
    }
}
