package com.company;

public class Coche {
    private int cantidadPuertas=4;

    public Coche(){}

    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void incCantidadPuertas() {
        this.cantidadPuertas ++;
    }
}
